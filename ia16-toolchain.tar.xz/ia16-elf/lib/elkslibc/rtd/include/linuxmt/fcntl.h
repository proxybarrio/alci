#ifndef __LINUXMT_FCNTL_H
#define __LINUXMT_FCNTL_H

/*
 *	Definitions taken from the i386 Linux kernel.
 */

/* open/fcntl */

#define O_ACCMODE	  0003
#define O_RDONLY	    00
#define O_WRONLY	    01
#define O_RDWR		    02
#define O_CREAT		  0100	/* not fcntl */
#define O_EXCL		  0200	/* not fcntl */
#define O_NOCTTY	  0400	/* not fcntl */
#define O_TRUNC		 01000	/* not fcntl */
#define O_APPEND	 02000
#define O_NONBLOCK	 04000
#define O_NDELAY	O_NONBLOCK
#define O_ALT		010000  /* use alternate interpretation of f_pos in /dev/kmem */

#define F_DUPFD		0	/* dup */
#define F_GETFD		1	/* get cloexec flag */
#define F_SETFD		2	/* set cloexec flag */
#define F_GETFL		3	/* get f_flags */
#define F_SETFL		4   /* set f_flags (O_APPEND, O_NONBLOCK only) */

#define FD_CLOEXEC	1	/* for F_GETFD, F_SETFD */

#if UNUSED
/* unimplemented options */
#define O_SYNC		010000	/* Not supported */
#define FASYNC		020000	/* Not supported */

#define F_GETLK		5
#define F_SETLK		6
#define F_SETLKW	7
#define F_SETOWN	8	/*  for sockets. */
#define F_GETOWN	9	/*  for sockets. */

/* for posix fcntl() and lockf() */
#define F_RDLCK		0
#define F_WRLCK		1
#define F_UNLCK		2

/* for old implementation of bsd flock () */
#define F_EXLCK		4	/* or 3 */
#define F_SHLCK		8	/* or 4 */

/* operations for bsd flock(), also used by the kernel implementation */
#define LOCK_SH		1	/* shared lock */
#define LOCK_EX		2	/* exclusive lock */
#define LOCK_NB		4	/* or'd with one of the above to prevent blocking */
#define LOCK_UN		8	/* remove lock */
#endif

#endif
