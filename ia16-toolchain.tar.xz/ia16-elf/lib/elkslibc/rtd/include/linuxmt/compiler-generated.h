#define UTS_RELEASE "0.9.2"
#define UTS_VERSION "commit 3e6b940 15 Nov 2026 15:35:15 +0000"
