/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-src/configure --target=ia16-elf --prefix=/home/claude/elks/cross --without-headers --enable-languages=c --disable-libssp --without-isl --disable-nls --disable-werror";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
